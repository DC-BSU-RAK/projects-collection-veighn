package com.example.multipageapplication

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // NAvigation logic
        val pageInfo = findViewById<ScrollView>(R.id.page_info)
        val pageHome = findViewById<ScrollView>(R.id.page_home)
        val pageSettings = findViewById<ScrollView>(R.id.page_settings)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            pageInfo.visibility = View.GONE
            pageHome.visibility = View.GONE
            pageSettings.visibility = View.GONE

            when (item.itemId) {
                R.id.nav_info -> pageInfo.visibility = View.VISIBLE
                R.id.nav_home -> pageHome.visibility = View.VISIBLE
                R.id.nav_settings -> pageSettings.visibility = View.VISIBLE
            }
            true
        }

        // Calculator logic
        val etFlour = findViewById<EditText>(R.id.et_flour)
        val tvFlourUnit = findViewById<TextView>(R.id.tv_flour_unit)
        val btnMinusFlour = findViewById<Button>(R.id.btn_minus_flour)
        val btnPlusFlour = findViewById<Button>(R.id.btn_plus_flour)

        val seekHydration = findViewById<SeekBar>(R.id.seek_hydration)
        val tvHydrationVal = findViewById<TextView>(R.id.tv_hydration_val)

        val etSalt = findViewById<EditText>(R.id.et_salt)
        val etYeast = findViewById<EditText>(R.id.et_yeast)
        val btnCalculate = findViewById<Button>(R.id.btn_calculate)

        val tvResFlour = findViewById<TextView>(R.id.tv_res_flour)
        val tvResWater = findViewById<TextView>(R.id.tv_res_water)
        val tvResSalt = findViewById<TextView>(R.id.tv_res_salt)
        val tvResYeast = findViewById<TextView>(R.id.tv_res_yeast)
        val tvResTotal = findViewById<TextView>(R.id.tv_res_total)

        val sharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        btnMinusFlour.setOnClickListener {
            var current = etFlour.text.toString().toIntOrNull() ?: 1000
            if (current > 50) current -= 50
            etFlour.setText(current.toString())
        }

        btnPlusFlour.setOnClickListener {
            var current = etFlour.text.toString().toIntOrNull() ?: 1000
            current += 50
            etFlour.setText(current.toString())
        }

        seekHydration.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val actualHydration = progress + 50
                tvHydrationVal.text = "$actualHydration%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnCalculate.setOnClickListener {
            val flour = etFlour.text.toString().toDoubleOrNull() ?: 1000.0
            val hydrationPct = (seekHydration.progress + 50).toDouble()
            val saltPct = etSalt.text.toString().toDoubleOrNull() ?: 2.0
            val yeastPct = etYeast.text.toString().toDoubleOrNull() ?: 0.5

            val water = flour * (hydrationPct / 100.0)
            val salt = flour * (saltPct / 100.0)
            val yeast = flour * (yeastPct / 100.0)
            val total = flour + water + salt + yeast

            val isImperial = sharedPreferences.getBoolean("ImperialUnits", false)
            val unitStr = if (isImperial) "oz" else "g"

            tvResFlour.text = "Flour: ${String.format("%.0f", flour)}$unitStr"
            tvResWater.text = "Water: ${String.format("%.1f", water)}$unitStr"
            tvResSalt.text = "Salt: ${String.format("%.1f", salt)}$unitStr"
            tvResYeast.text = "Yeast: ${String.format("%.1f", yeast)}$unitStr"
            tvResTotal.text = "Total Dough: ${String.format("%.0f", total)}$unitStr"
        }

        // settings logic
        val switchUnits = findViewById<Switch>(R.id.switch_units)
        val tvUnitsStatus = findViewById<TextView>(R.id.tv_units_status)
        val etSettingsName = findViewById<EditText>(R.id.et_settings_name)
        val btnSaveName = findViewById<TextView>(R.id.btn_save_name)

        // name logic
        val savedName = sharedPreferences.getString("ChefName", "Pizza Chef")
        etSettingsName.setText(savedName)

        btnSaveName.setOnClickListener {
            val newName = etSettingsName.text.toString().trim()
            if (newName.isNotEmpty()) {
                sharedPreferences.edit().putString("ChefName", newName).apply()
                Toast.makeText(this@MainActivity, "Chef Profile Updated!", Toast.LENGTH_SHORT).show()
                etSettingsName.clearFocus()
            }
        }

        // units logic
        val isImperialOn = sharedPreferences.getBoolean("ImperialUnits", false)
        switchUnits.isChecked = isImperialOn
        tvUnitsStatus.text = if (isImperialOn) "Imperial (oz)" else "Metric (grams)"
        tvFlourUnit.text = if (isImperialOn) "ounces" else "grams"
        btnCalculate.performClick()

        switchUnits.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("ImperialUnits", isChecked).apply()
            tvUnitsStatus.text = if (isChecked) "Imperial (oz)" else "Metric (grams)"
            tvFlourUnit.text = if (isChecked) "ounces" else "grams"
            btnCalculate.performClick()
        }
    }
}