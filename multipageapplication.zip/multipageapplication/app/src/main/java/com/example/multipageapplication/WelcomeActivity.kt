package com.example.multipageapplication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        val sharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val btnNext = findViewById<Button>(R.id.btn_next)
        val etChefName = findViewById<EditText>(R.id.et_chef_name)

        // Pre fill the text box if the user already have a saved name
        val savedName = sharedPreferences.getString("ChefName", "")
        if (!savedName.isNullOrEmpty()) {
            etChefName.setText(savedName)
        }

        btnNext.setOnClickListener {
            val chefName = etChefName.text.toString().trim()

            if (chefName.isNotEmpty()) {
                // Save the name (in case they changed it here) and go to the app
                sharedPreferences.edit().putString("ChefName", chefName).apply()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Please tell us your Chef name!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}