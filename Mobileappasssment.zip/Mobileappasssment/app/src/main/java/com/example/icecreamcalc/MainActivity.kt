package com.example.icecreamcalc

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {

    private var selectedFlavor = ""
    private var selectedTopping = ""
    private var flavorEmoji = ""
    private var toppingEmoji = ""

    private lateinit var flavorButtons: List<Button>
    private lateinit var toppingButtons: List<Button>
    private lateinit var btnMakeIceCream: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val layoutMain = findViewById<ScrollView>(R.id.layout_main)
        val dimOverlay = findViewById<View>(R.id.dim_overlay)
        val cardIntroModal = findViewById<CardView>(R.id.card_intro_modal)

        btnMakeIceCream = findViewById(R.id.btn_make_icecream)
        val cardResult = findViewById<CardView>(R.id.card_result)
        val tvFinalText = findViewById<TextView>(R.id.tv_final_text)
        val tvFinalSubtext = findViewById<TextView>(R.id.tv_final_subtext)
        val tvFinalEmojis = findViewById<TextView>(R.id.tv_final_emojis)

        // --- GET STARTED BUTTON ---
        findViewById<Button>(R.id.btn_get_started).setOnClickListener {
            cardIntroModal.visibility = View.GONE
            dimOverlay.visibility = View.GONE
        }

        // --- CALCULATOR SETUP ---
        flavorButtons = listOf(
            findViewById(R.id.btn_vanilla), findViewById(R.id.btn_choco),
            findViewById(R.id.btn_straw), findViewById(R.id.btn_mint),
            findViewById(R.id.btn_cookie), findViewById(R.id.btn_pistachio)
        )

        toppingButtons = listOf(
            findViewById(R.id.btn_sprinkles), findViewById(R.id.btn_cherry),
            findViewById(R.id.btn_caramel), findViewById(R.id.btn_nuts),
            findViewById(R.id.btn_whip), findViewById(R.id.btn_chips)
        )

        setupFlavorButton(R.id.btn_vanilla, "Vanilla", "🍦")
        setupFlavorButton(R.id.btn_choco, "Chocolate", "🍫")
        setupFlavorButton(R.id.btn_straw, "Strawberry", "🍓")
        setupFlavorButton(R.id.btn_mint, "Mint", "🌿")
        setupFlavorButton(R.id.btn_cookie, "Cookie Dough", "🍪")
        setupFlavorButton(R.id.btn_pistachio, "Pistachio", "🥜")

        setupToppingButton(R.id.btn_sprinkles, "Sprinkles", "✨")
        setupToppingButton(R.id.btn_cherry, "Cherry", "🍒")
        setupToppingButton(R.id.btn_caramel, "Caramel", "🍯")
        setupToppingButton(R.id.btn_nuts, "Nuts", "🥜")
        setupToppingButton(R.id.btn_whip, "Cream", "☁️")
        setupToppingButton(R.id.btn_chips, "Chips", "🍫")

        // --- MAKE ICE CREAM (Result Modal) ---
        btnMakeIceCream.setOnClickListener {
            tvFinalEmojis.text = "$flavorEmoji $toppingEmoji"
            tvFinalText.text = "$selectedFlavor Ice Cream"
            tvFinalSubtext.text = "with $selectedTopping"

            dimOverlay.alpha = 0f
            dimOverlay.visibility = View.VISIBLE
            dimOverlay.animate().alpha(1f).setDuration(300).start()

            cardResult.alpha = 0f
            cardResult.scaleX = 0.8f
            cardResult.scaleY = 0.8f
            cardResult.visibility = View.VISIBLE

            cardResult.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(300)
                .start()
        }

        // --- RESET BUTTON ---
        findViewById<Button>(R.id.btn_reset).setOnClickListener {
            selectedFlavor = ""
            selectedTopping = ""

            dimOverlay.visibility = View.GONE
            cardResult.visibility = View.GONE
            btnMakeIceCream.visibility = View.GONE

            flavorButtons.forEach { it.alpha = 1.0f }
            toppingButtons.forEach { it.alpha = 1.0f }
        }
    }

    private fun setupFlavorButton(buttonId: Int, name: String, emoji: String) {
        val btn = findViewById<Button>(buttonId)
        btn.setOnClickListener {
            selectedFlavor = name
            flavorEmoji = emoji
            flavorButtons.forEach { it.alpha = 0.4f }
            btn.alpha = 1.0f
            checkSelections()
        }
    }

    private fun setupToppingButton(buttonId: Int, name: String, emoji: String) {
        val btn = findViewById<Button>(buttonId)
        btn.setOnClickListener {
            selectedTopping = name
            toppingEmoji = emoji
            toppingButtons.forEach { it.alpha = 0.4f }
            btn.alpha = 1.0f
            checkSelections()
        }
    }

    private fun checkSelections() {
        if (selectedFlavor.isNotEmpty() && selectedTopping.isNotEmpty()) {
            btnMakeIceCream.visibility = View.VISIBLE
        }
    }
}